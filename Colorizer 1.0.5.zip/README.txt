
#####################################    # # # # # # # # # # # #
## Welcome to Colorizer.exe       ##   #   Written by         #
##   Live v1.0.5               ##   #  Jacob L Chrzanowski  #
################################   # # # # # # # # # # # # #
	
Colorizer is unfinished and does not look like it will in its finished state.


To use Colorizer:
 • Extract .zip to a safe place
 • Copy the .exe and paste it to your desktop as a shortcut
 • Run the shortcut
 • Select some text in CALO notes and Ctrl+RightClick on it
 • Select the color modifier you would like to use
 ○ Some color option do not have an example shown.
    These option are still functional.

------ Version History

v1.0.5
•Added icons

v1.0.4
•Changed red to be as red as possible
•Lowered wait time after copy

v1.0.3h
•Fixed 'no percent around Clipboard' bug

v1.0.3
•Added tray icon

v1.0.2
•Added bold option
•Fixed red color to be not orange
•Changed code structure to paste clipboard inside each function.
••Same number of lines, more code inside if/elseif statements

v1.0.1
•First version
•It works with minimal bugs
•Only first four options have icons











